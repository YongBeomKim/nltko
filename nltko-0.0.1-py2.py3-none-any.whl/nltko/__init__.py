#!/usr/bin/env python
# -*- coding: utf-8, euc-kr -*-
## :e ++enc=utf-8

from ._token.news import News
from ._token.morph import Morph