#!/usr/bin/env python
# -*- coding: utf-8, euc-kr -*-
## :e ++enc=utf-8

from ._token.code import cal_sum