from .base import *


def cal_sum(x,y):
    return x + y